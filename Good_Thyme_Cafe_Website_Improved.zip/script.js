const nav=document.querySelector('.site-header nav'), toggle=document.querySelector('.menu-toggle');
toggle.addEventListener('click',()=>{nav.classList.toggle('open');toggle.textContent=nav.classList.contains('open')?'×':'☰'});
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');toggle.textContent='☰'}));

const menus={
 morning:[
  ['Avocado toast','Smashed avocado, toast and fresh toppings.','R'],
  ['Cafe breakfast','A satisfying breakfast to start the day.','R'],
  ['Something sweet','Ask what baked goodness is fresh today.','R']
 ],
 anytime:[
  ['Cafe favourites','Comforting meals made for a relaxed catch-up.','R'],
  ['Light bites','Easy-going options for a smaller appetite.','R'],
  ['Something filling','Ask the team about today’s specials.','R']
 ],
 drinks:[
  ['Coffee','Your usual, your way.','R'],
  ['Cold drinks','Something refreshing for a warm Cape Town day.','R'],
  ['Something special','Ask the team what’s pouring today.','R']
 ]
};
const panel=document.querySelector('#menuPanel');
function renderMenu(key){
 panel.innerHTML=menus[key].map(x=>`<article class="dish"><div class="dish-top"><span>${x[0]}</span><span class="dish-price">${x[2]}</span></div><p>${x[1]}</p></article>`).join('');
}
document.querySelectorAll('.menu-tabs button').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('.menu-tabs button').forEach(x=>x.classList.remove('active'));b.classList.add('active');renderMenu(b.dataset.tab);
}));
renderMenu('morning');

const form=document.querySelector('#bookingForm'), msg=document.querySelector('#formMessage');
form.addEventListener('submit',e=>{
 e.preventDefault();
 const data=new FormData(form), name=String(data.get('name')||'').trim(), date=String(data.get('date')||'');
 if(!name||!date){msg.textContent='Please add your name and preferred date.';return}
 msg.textContent=`Thanks, ${name}! Your request is ready to send — connect this form to the cafe's email or booking system before publishing.`;
 form.reset();
});
